package es.ulpgc.eite.cleancode.advclickcounter.app;

public class ClickToCounterState {

  public String data;
}
