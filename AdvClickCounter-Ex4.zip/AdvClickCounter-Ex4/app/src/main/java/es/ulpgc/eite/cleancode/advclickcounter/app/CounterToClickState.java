package es.ulpgc.eite.cleancode.advclickcounter.app;

public class CounterToClickState {

  public String data;
}
