package es.ulpgc.eite.cleancode.advclickcounter.data;

public interface BaseData {

  Integer getValue();
}
