package es.ulpgc.eite.cleancode.advclickcounter.counters;

public class CounterListState extends CounterListViewModel {

  // put the model state here
}
