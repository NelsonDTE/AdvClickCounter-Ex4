package es.ulpgc.eite.cleancode.advclickcounter.clicks;

public class ClickListState extends ClickListViewModel {

  // put the model state here
  public Integer values;
}
